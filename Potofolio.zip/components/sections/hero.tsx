"use client"

export default function Hero() {
  return (
    <section
      id="home"
      className="container mx-auto px-4 pt-28 md:pt-32 pb-16 md:pb-24 scroll-mt-24"
      aria-labelledby="home-heading"
    >
      {/* Page marker to echo PDF style */}
      <p className="text-xs text-muted-foreground mb-4">{"Home Page | 01"}</p>

      <div className="grid md:grid-cols-2 gap-10 items-center">
        <div className="space-y-6">
          <h1 id="home-heading" className="text-3xl md:text-5xl font-semibold text-balance">
            {"Muhammad Andri Wibowo"}
          </h1>
          <p className="text-base md:text-lg text-pretty">
            {
              "I am a passionate UI/UX Design Enthusiast dedicated to creating digital solutions that are not only functional but also intuitive and delightful to use."
            }
          </p>
          <p className="text-muted-foreground text-pretty">
            {"I believe that great design is born from a deep understanding of user needs."}
          </p>
          <div className="flex items-center gap-4">
            <a
              href="#projects"
              className="inline-flex items-center rounded-md px-5 py-3 bg-[var(--brand)] text-[var(--brand-foreground)] hover:brightness-95 transition-colors"
            >
              {"Explore My Work"}
            </a>
            <a href="#about" className="text-sm underline underline-offset-4 hover:text-foreground transition-colors">
              {"About Me"}
            </a>
          </div>
        </div>

        {/* Portrait placeholder to reflect PDF layout that includes a photo */}
        <div className="relative">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Anjay-5pfdAx8zgKhNbMt9SV5oXAoSYD1MuL.png"
            alt="Portrait of a UI/UX designer with glasses against a red background"
            className="mx-auto w-72 md:w-96 rounded-[var(--radius-lg)] border border-[var(--color-border)] object-cover"
          />
        </div>
      </div>
    </section>
  )
}
